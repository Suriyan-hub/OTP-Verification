package com.example.demo.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Otp {
    @Id
    private String email;
    private String code;
    private LocalDateTime expiry;
	public Otp(String email, String code, LocalDateTime expiry) {
		super();
		this.email = email;
		this.code = code;
		this.expiry = expiry;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public LocalDateTime getExpiry() {
		return expiry;
	}
	public void setExpiry(LocalDateTime expiry) {
		this.expiry = expiry;
	}
	public Otp() {
		super();
	}
    
}