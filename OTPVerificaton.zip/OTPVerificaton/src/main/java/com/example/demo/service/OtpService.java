package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.model.Otp;
import com.example.demo.repository.OtpRepository;

@Service
public class OtpService {
	
    @Autowired 
    private JavaMailSender mailSender;
    @Autowired 
    private OtpRepository otpRepo;

    public void generateAndSendOtp(String email) {
        String otp = String.valueOf(new Random().nextInt(899999) + 100000);
        Otp otpEntity = new Otp(email, otp, LocalDateTime.now().plusMinutes(5));
        otpRepo.save(otpEntity);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp);
        mailSender.send(message);
    }

    public boolean verifyOtp(String email, String code) {
        Optional<Otp> otp = otpRepo.findById(email);
        if (otp.isPresent() && otp.get().getCode().equals(code) &&
            otp.get().getExpiry().isAfter(LocalDateTime.now())) {
            otpRepo.deleteById(email); // one-time use
            return true;
        }
        return false;
    }
}